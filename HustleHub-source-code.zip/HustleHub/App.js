import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, ScrollView, TouchableOpacity,
  StatusBar, StyleSheet, Alert
} from "react-native";

const COLORS = {
  navy: "#101A2C", navy2: "#18263D", gold: "#F2B84B",
  cream: "#F7F5F0", white: "#FFFFFF", muted: "#788397",
  line: "#E7E9EE", green: "#247A59"
};

const STARTER_LISTINGS = [
  { id: "1", title: "Weekend garden helper", category: "Part-time", pay: "N$350 / day", location: "Tsumeb", description: "Help with basic garden cleaning and watering on Saturdays." },
  { id: "2", title: "Social media assistant", category: "Online", pay: "N$1,200 / month", location: "Remote", description: "Create simple posts and reply to customer messages." },
  { id: "3", title: "Homemade lunch orders", category: "Business", pay: "Set your price", location: "Tsumeb", description: "Promote your home-cooked meals to nearby customers." },
  { id: "4", title: "Delivery and errands", category: "Services", pay: "N$80 / task", location: "Tsumeb", description: "Offer local collection, delivery and errand services." },
];

const CATEGORIES = ["All", "Part-time", "Online", "Business", "Services"];

export default function App() {
  const [tab, setTab] = useState("Explore");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [listings, setListings] = useState(STARTER_LISTINGS);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [pay, setPay] = useState("");
  const [location, setLocation] = useState("Tsumeb");

  const filtered = useMemo(() => listings.filter(item => {
    const matchesCategory = category === "All" || item.category === category;
    const text = `${item.title} ${item.description} ${item.location}`.toLowerCase();
    return matchesCategory && text.includes(query.toLowerCase());
  }), [listings, category, query]);

  function publish() {
    if (!title.trim() || !description.trim()) {
      Alert.alert("A little more detail", "Please add a title and description before publishing.");
      return;
    }
    setListings([{ id: String(Date.now()), title: title.trim(), category: "Services",
      pay: pay.trim() || "Contact for price", location: location.trim() || "Namibia",
      description: description.trim() }, ...listings]);
    setTitle(""); setDescription(""); setPay("");
    setTab("Explore");
    Alert.alert("Listing added", "Your demo listing is now visible in HustleHub on this device.");
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.navy} />
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>HUSTLE<Text style={{color: COLORS.gold}}>HUB</Text></Text>
          <Text style={styles.tagline}>Find your next opportunity.</Text>
        </View>
        <View style={styles.countryPill}><Text style={styles.countryText}>🇳🇦 NAMIBIA</Text></View>
      </View>

      <View style={styles.welcome}>
        <Text style={styles.eyebrow}>YOUR NEXT MOVE STARTS HERE</Text>
        <Text style={styles.hero}>Turn your skills{`\n`}into <Text style={{color: COLORS.gold}}>income.</Text></Text>
        <Text style={styles.heroSub}>Discover local gigs, online work and small-business opportunities.</Text>
      </View>

      <View style={styles.nav}>
        {["Explore", "Post a hustle", "Profile"].map(item => (
          <TouchableOpacity key={item} onPress={() => setTab(item)} style={[styles.navItem, tab === item && styles.navActive]}>
            <Text style={[styles.navText, tab === item && styles.navTextActive]}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {tab === "Explore" && (
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.sectionTitle}>Explore opportunities</Text>
          <TextInput value={query} onChangeText={setQuery} placeholder="Search jobs, skills or services..." placeholderTextColor="#9AA3B2" style={styles.search} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chips}>
            {CATEGORIES.map(item => (
              <TouchableOpacity key={item} onPress={() => setCategory(item)} style={[styles.chip, category === item && styles.chipActive]}>
                <Text style={[styles.chipText, category === item && styles.chipTextActive]}>{item}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <View style={styles.rowBetween}>
            <Text style={styles.sectionTitle}>Latest opportunities</Text>
            <Text style={styles.count}>{filtered.length} found</Text>
          </View>
          {filtered.map(item => (
            <View key={item.id} style={styles.listing}>
              <View style={styles.listingTop}>
                <Text style={styles.category}>{item.category.toUpperCase()}</Text>
                <Text style={styles.location}>⌖ {item.location}</Text>
              </View>
              <Text style={styles.listingTitle}>{item.title}</Text>
              <Text style={styles.description}>{item.description}</Text>
              <View style={styles.listingBottom}>
                <Text style={styles.pay}>{item.pay}</Text>
                <TouchableOpacity onPress={() => Alert.alert("Opportunity details", `${item.title}\n\n${item.description}\n\nLocation: ${item.location}\nPay: ${item.pay}\n\nThis is sample content. Contact and application features will be connected in a later version.`)} style={styles.detailsButton}>
                  <Text style={styles.detailsText}>View details →</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
          {filtered.length === 0 && <Text style={styles.empty}>No matches yet. Try another search or category.</Text>}
          <Text style={styles.disclaimer}>Demo listings only. Verify opportunities before sharing personal information or making payments.</Text>
        </ScrollView>
      )}

      {tab === "Post a hustle" && (
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.sectionTitle}>Share an opportunity</Text>
          <Text style={styles.formIntro}>Have a skill, service or job to offer? Add it to this demo feed.</Text>
          <Text style={styles.label}>TITLE</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder="e.g. I offer hair braiding" style={styles.input} />
          <Text style={styles.label}>DESCRIPTION</Text>
          <TextInput value={description} onChangeText={setDescription} placeholder="Describe what you offer..." multiline style={[styles.input, styles.multiline]} />
          <Text style={styles.label}>PRICE / PAY</Text>
          <TextInput value={pay} onChangeText={setPay} placeholder="e.g. N$150 per service" style={styles.input} />
          <Text style={styles.label}>LOCATION</Text>
          <TextInput value={location} onChangeText={setLocation} placeholder="Town or Remote" style={styles.input} />
          <TouchableOpacity style={styles.primaryButton} onPress={publish}><Text style={styles.primaryButtonText}>Publish demo listing</Text></TouchableOpacity>
          <Text style={styles.disclaimer}>This first version stores new listings only in the app's temporary local state. Online publishing will be added when we connect a database.</Text>
        </ScrollView>
      )}

      {tab === "Profile" && (
        <ScrollView contentContainerStyle={styles.content}>
          <Text style={styles.sectionTitle}>Your HustleHub profile</Text>
          <View style={styles.profileCard}>
            <View style={styles.avatar}><Text style={styles.avatarText}>H</Text></View>
            <Text style={styles.profileName}>Welcome to HustleHub</Text>
            <Text style={styles.description}>Your profile space is ready. Account registration, saved listings and messaging will be added in the next development stage.</Text>
          </View>
          <View style={styles.infoCard}><Text style={styles.infoTitle}>Built for Namibia 🇳🇦</Text><Text style={styles.description}>A place to discover opportunities, promote services and grow your income.</Text></View>
        </ScrollView>
      )}

      <View style={styles.footer}><Text style={styles.footerText}>HUSTLEHUB  •  OPPORTUNITY IS EVERYWHERE</Text></View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.cream },
  header: { backgroundColor: COLORS.navy, paddingHorizontal: 22, paddingTop: 14, paddingBottom: 18, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  brand: { color: COLORS.white, fontSize: 22, fontWeight: "900", letterSpacing: 1.5 },
  tagline: { color: "#C4CCDA", fontSize: 11, marginTop: 3 },
  countryPill: { backgroundColor: COLORS.navy2, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 8 },
  countryText: { color: COLORS.gold, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  welcome: { backgroundColor: COLORS.navy, paddingHorizontal: 22, paddingTop: 12, paddingBottom: 28 },
  eyebrow: { color: COLORS.gold, fontSize: 9, fontWeight: "800", letterSpacing: 2 },
  hero: { color: COLORS.white, fontSize: 34, lineHeight: 39, fontWeight: "900", marginTop: 10 },
  heroSub: { color: "#C4CCDA", fontSize: 13, lineHeight: 19, marginTop: 10, maxWidth: 300 },
  nav: { flexDirection: "row", backgroundColor: COLORS.white, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: COLORS.line },
  navItem: { flex: 1, alignItems: "center", paddingVertical: 15, borderBottomWidth: 3, borderBottomColor: "transparent" },
  navActive: { borderBottomColor: COLORS.gold },
  navText: { color: COLORS.muted, fontWeight: "700", fontSize: 12 },
  navTextActive: { color: COLORS.navy },
  content: { padding: 18, paddingBottom: 30 },
  sectionTitle: { color: COLORS.navy, fontSize: 19, fontWeight: "900", marginBottom: 12 },
  search: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.line, borderRadius: 12, paddingHorizontal: 15, paddingVertical: 13, fontSize: 13, color: COLORS.navy },
  chips: { marginVertical: 15, flexGrow: 0 },
  chip: { borderWidth: 1, borderColor: COLORS.line, backgroundColor: COLORS.white, borderRadius: 20, paddingHorizontal: 15, paddingVertical: 9, marginRight: 8 },
  chipActive: { backgroundColor: COLORS.navy, borderColor: COLORS.navy },
  chipText: { color: COLORS.muted, fontWeight: "700", fontSize: 11 },
  chipTextActive: { color: COLORS.white },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 3 },
  count: { color: COLORS.muted, fontSize: 11, marginBottom: 12 },
  listing: { backgroundColor: COLORS.white, borderRadius: 15, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: COLORS.line },
  listingTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  category: { color: COLORS.green, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  location: { color: COLORS.muted, fontSize: 10 },
  listingTitle: { color: COLORS.navy, fontSize: 16, fontWeight: "800", marginTop: 10 },
  description: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 6 },
  listingBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: COLORS.line },
  pay: { color: COLORS.navy, fontSize: 12, fontWeight: "900" },
  detailsButton: { backgroundColor: "#FFF4DB", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 8 },
  detailsText: { color: COLORS.navy, fontSize: 10, fontWeight: "800" },
  empty: { color: COLORS.muted, textAlign: "center", padding: 25 },
  disclaimer: { color: COLORS.muted, fontSize: 10, lineHeight: 15, marginTop: 12 },
  formIntro: { color: COLORS.muted, fontSize: 12, marginBottom: 20 },
  label: { color: COLORS.navy, fontSize: 10, fontWeight: "900", letterSpacing: 1, marginBottom: 7, marginTop: 12 },
  input: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.line, borderRadius: 11, padding: 13, fontSize: 13, color: COLORS.navy },
  multiline: { minHeight: 100, textAlignVertical: "top" },
  primaryButton: { backgroundColor: COLORS.navy, borderRadius: 12, padding: 16, alignItems: "center", marginTop: 22 },
  primaryButtonText: { color: COLORS.white, fontWeight: "900", fontSize: 13 },
  profileCard: { backgroundColor: COLORS.white, borderRadius: 16, padding: 22, alignItems: "center", borderWidth: 1, borderColor: COLORS.line },
  avatar: { width: 62, height: 62, borderRadius: 31, backgroundColor: COLORS.navy, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  avatarText: { color: COLORS.gold, fontWeight: "900", fontSize: 28 },
  profileName: { color: COLORS.navy, fontWeight: "900", fontSize: 17, marginBottom: 8 },
  infoCard: { backgroundColor: "#FFF4DB", borderRadius: 14, padding: 17, marginTop: 14 },
  infoTitle: { color: COLORS.navy, fontWeight: "900", fontSize: 14 },
  footer: { backgroundColor: COLORS.navy, padding: 12, alignItems: "center" },
  footerText: { color: "#AAB4C4", fontSize: 8, fontWeight: "800", letterSpacing: 1.2 }
});
